"""unisemble_client: the station application's SDK for the UnisemBLE box.

    client = UnisembleClient(box_url, station_key)
    user = client.login(phone, pin)
    block = client.request_block(5000, "UNISEM-A")
    result = client.report([Module(qr, mac, passed)])
    client.logout()
"""
from .client import UnisembleClient
from .models import Block, Module, ReportResult, User
from .codec import InvalidMacError, int_to_mac, mac_to_int
from .errors import (
    AccountLocked,
    BoxUnreachable,
    ClientBusy,
    NotLoggedIn,
    PinChangeRequired,
    Refused,
    SessionExpired,
    UnisembleError,
    WrongPin,
)
from . import errors

__all__ = [
    "UnisembleClient",
    "Module",
    "Block",
    "ReportResult",
    "User",
    "mac_to_int",
    "int_to_mac",
    "InvalidMacError",
    "UnisembleError",
    "ClientBusy",
    "BoxUnreachable",
    "PinChangeRequired",
    "WrongPin",
    "AccountLocked",
    "NotLoggedIn",
    "SessionExpired",
    "Refused",
    "errors",
]

__version__ = "6.1.1"
