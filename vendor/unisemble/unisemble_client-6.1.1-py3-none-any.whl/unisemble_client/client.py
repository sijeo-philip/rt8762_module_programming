"""UnisembleClient: the station's connection to one box.

The client is either ready or busy. Each call holds the client for as long as it
runs, including its retries; a second call meanwhile raises ``ClientBusy`` at once
and sends nothing. The client makes the request ids, timestamps and retries, keeps
the operator session from ``login()``, and maps every refusal to one error class.
"""
from __future__ import annotations

import datetime as _dt
import functools
import threading
import time
import urllib.parse
import uuid
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple, TypeVar

from .codec import normalize_mac
from .errors import (
    AccountLocked,
    BoxUnreachable,
    ClientBusy,
    NotLoggedIn,
    PinChangeRequired,
    Refused,
    SessionExpired,
    TransportError,
    WrongPin,
)
from .models import Block, Module, ReportResult, User
from .transport import Response, Transport, UrllibTransport

API_PREFIX = "/api/v1"

# Retried calls: 4 attempts of at most 3 s each (the box is on the LAN), waiting 1 s,
# 2 s, 4 s between them (a Retry-After from the box is honoured, capped at 5 s). A box
# that never answers keeps a call busy for about 20 s (4 x 3 s + 7 s).
REQUEST_TIMEOUT_SECONDS = 3.0
RETRY_ATTEMPTS = 4
RETRY_BACKOFF_SECONDS = (1.0, 2.0, 4.0)
RETRY_AFTER_MAX_SECONDS = 5.0
MAX_MODULES_PER_REPORT = 500

_sleep = time.sleep  # tests replace this so retries do not really wait

T = TypeVar("T")


def _one_at_a_time(method: Callable[..., T]) -> Callable[..., T]:
    """Hold the client for the whole call; refuse a second call with ClientBusy."""

    @functools.wraps(method)
    def wrapper(self: "UnisembleClient", *args: Any, **kwargs: Any) -> T:
        if not self._busy.acquire(blocking=False):
            raise ClientBusy(f"{method.__name__}() refused: another call on this client is still in progress")
        try:
            return method(self, *args, **kwargs)
        finally:
            self._busy.release()

    return wrapper


def _check_box_url(box_url: str) -> None:
    """Refuse a malformed box URL at once (ValueError), so a typo is not retried
    and reported as BoxUnreachable on the first call."""
    try:
        parts = urllib.parse.urlsplit(box_url)
        parts.port  # raises ValueError for a non-numeric or out-of-range port
    except ValueError as e:
        raise ValueError(f"box_url {box_url!r} is not a valid URL: {e}") from None
    if parts.scheme not in ("http", "https") or not parts.hostname:
        raise ValueError(f"box_url {box_url!r} must look like http://<box-host>:<port>")


class _Retryable(Exception):
    """Internal: an answer worth trying again (no answer, 5xx, box not ready)."""

    def __init__(self, detail: str, retry_after: Optional[float] = None) -> None:
        super().__init__(detail)
        self.detail = detail
        self.retry_after = retry_after


class UnisembleClient:
    """The connection to one box for one station. One call runs at a time."""

    def __init__(
        self,
        box_url: str,
        station_key: str,
        *,
        transport: Optional[Transport] = None,
    ) -> None:
        _check_box_url(box_url)
        self._base = box_url.rstrip("/") + API_PREFIX
        self._key = station_key
        self._transport: Transport = transport or UrllibTransport()
        self._busy = threading.Lock()
        self._session: Optional[str] = None
        # For change_pin(): the person of the last login(), if it logged them in or
        # raised PinChangeRequired. One person per client: login() ends the last one.
        self._phone: Optional[str] = None
        self._must_change = False  # the last login() raised PinChangeRequired

    # ── people ──────────────────────────────────────────────────────────────
    @_one_at_a_time
    def login(self, phone: str, pin: str) -> User:
        """Log an operator in and return who they are. Whoever was logged in on
        this client is logged out first, whatever the outcome. Raises
        PinChangeRequired, WrongPin, AccountLocked, Refused (not_allowed)."""
        self._logout()
        return self._login(phone, pin)

    @_one_at_a_time
    def change_pin(self, current_pin: str, new_pin: str) -> Optional[User]:
        """Change the PIN of the person of the last login(): logged in, or just
        refused with PinChangeRequired (a successful change then logs them in and
        returns the User, as login() does; otherwise None)."""
        if self._phone is None:
            raise NotLoggedIn("change_pin() needs a login() first: the client does not know whose PIN to change")
        r = self._once("POST", "/operator/change-pin",
                       {"phone": self._phone, "current_pin": current_pin, "new_pin": new_pin})
        if r.status != 200:
            self._raise_credential_error(r)
        if self._must_change:
            return self._login(self._phone, new_pin)
        return None

    @_one_at_a_time
    def clear_hold(self, phone: str, pin: str) -> bool:
        """A supervisor's phone and PIN, typed at the station. True: every hold on
        this station is cleared (or there was none). False: this person may not
        clear holds (not a supervisor, or must set a new PIN first); nothing changed."""
        r = self._once("POST", "/station/hold/clear", {"phone": phone, "pin": pin})
        if r.status != 200:
            self._raise_credential_error(r)
        return bool((r.body or {}).get("cleared"))

    @_one_at_a_time
    def logout(self) -> None:
        """Log the operator out. The client forgets the session whatever the answer;
        with no one logged in it sends nothing."""
        self._logout()

    def _logout(self) -> None:
        session, self._session = self._session, None
        self._phone = None
        self._must_change = False
        if session is None:
            return
        self._once("POST", "/operator/logout", {}, session=session)

    # ── addresses ───────────────────────────────────────────────────────────
    @_one_at_a_time
    def request_block(self, size: int, master_range: str) -> Block:
        """A new block of ``size`` addresses from ``master_range``: the current
        block, and again later for the reserve."""
        r = self._with_retries("POST", "/blocks/request", {
            "request_id": str(uuid.uuid4()),
            "requested_size": size,
            "master_range": master_range,
        })
        if r.status != 201:
            self._raise_refusal(r, not_found="master_range_unknown")
        b = r.body or {}
        return Block(
            block_id=int(b["block_id"]),
            first_mac=str(b["range_start"]),
            last_mac=str(b["range_end"]),
            size=int(b["size"]),
            master_range=master_range,
        )

    @_one_at_a_time
    def promote_block(self, old_block_id: int, new_block_id: int) -> None:
        """Tell the box the station has moved from ``old_block_id`` to
        ``new_block_id``. The old block is closed."""
        r = self._with_retries("POST", "/blocks/promote", {
            "nonce": str(uuid.uuid4()),
            "old_block_id": old_block_id,
            "new_block_id": new_block_id,
        })
        if r.status == 200:
            return
        if r.status == 409 and (r.body or {}).get("outcome") == "NOT_YET":
            raise Refused("block_not_found", str((r.body or {}).get("detail") or "promote out of order"))
        self._raise_refusal(r, not_found="block_not_found")

    # ── the record ──────────────────────────────────────────────────────────
    @_one_at_a_time
    def report(self, modules: Sequence[Module]) -> ReportResult:
        """Report finished modules, once the station's own process for them is
        fully done. May hold several trays (1 to 500 modules)."""
        modules = list(modules)
        wire = [_module_to_wire(m) for m in modules]  # InvalidMacError before anything is sent
        if not 1 <= len(wire) <= MAX_MODULES_PER_REPORT:
            raise Refused("bad_request", f"a report holds 1 to {MAX_MODULES_PER_REPORT} modules, got {len(wire)}")
        if self._session is None:
            raise NotLoggedIn("report() needs a logged-in operator")
        body = {
            "report_id": str(uuid.uuid4()),
            "finished_at": _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z"),
            "modules": wire,
        }
        r = self._with_retries("POST", "/reports", body, session=self._session)
        if r.status == 401 and _slug(r) == "operator-session-expired":
            self._session = None
            self._phone = None
            raise SessionExpired(_detail(r))
        if r.status != 200:
            self._raise_refusal(r)
        return _report_result(modules, r.body or {})

    # ── wire ────────────────────────────────────────────────────────────────
    def _login(self, phone: str, pin: str) -> User:
        r = self._once("POST", "/operator/login", {"phone": phone, "pin": pin})
        if r.status == 201:
            b = r.body or {}
            op = b["operator"]
            user = User(
                user_id=str(op["identity_user_id"]),
                name=str(op["display_name"]),
                phone=str(op["phone"]),
                role=str(op["role"]),
            )
            self._session = str(b["operator_session_token"])
            self._phone = phone
            self._must_change = False
            return user
        if r.status == 409 and _slug(r) == "must-change-pin":
            self._phone = phone
            self._must_change = True
            raise PinChangeRequired(_detail(r))
        self._raise_credential_error(r)

    def _headers(self, session: Optional[str]) -> Dict[str, str]:
        h = {
            "Authorization": f"Bearer {self._key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if session is not None:
            h["X-Operator-Session"] = session
        return h

    def _attempt(self, method: str, path: str, body: Dict[str, Any], session: Optional[str]) -> Response:
        """One request. Raises _Retryable for no answer, a 5xx, or a box not ready."""
        try:
            r = self._transport.request(method, self._base + path, self._headers(session), body, REQUEST_TIMEOUT_SECONDS)
        except TransportError as e:
            raise _Retryable(f"no answer from the box: {e}") from e
        if r.status >= 500:
            raise _Retryable(f"box error {r.status}: {_detail(r)}", _retry_after(r))
        if r.status == 409 and _slug(r).startswith("pairing-"):
            raise _Retryable(f"box not ready ({_slug(r)}): {_detail(r)}", _retry_after(r))
        return r

    def _once(self, method: str, path: str, body: Dict[str, Any], *, session: Optional[str] = None) -> Response:
        """A call made exactly once (a PIN is never re-sent blind)."""
        try:
            return self._attempt(method, path, body, session)
        except _Retryable as e:
            raise BoxUnreachable(e.detail) from None

    def _with_retries(self, method: str, path: str, body: Dict[str, Any], *, session: Optional[str] = None) -> Response:
        """The same body (and so the same request id) on every attempt."""
        last = ""
        for attempt in range(RETRY_ATTEMPTS):
            try:
                return self._attempt(method, path, body, session)
            except _Retryable as e:
                last = e.detail
                if attempt + 1 < RETRY_ATTEMPTS:
                    wait = RETRY_BACKOFF_SECONDS[attempt]
                    if e.retry_after is not None:
                        wait = min(e.retry_after, RETRY_AFTER_MAX_SECONDS)
                    _sleep(wait)
        raise BoxUnreachable(f"after {RETRY_ATTEMPTS} attempts: {last}")

    def _raise_credential_error(self, r: Response) -> None:
        if r.status == 401 and _slug(r) == "invalid-credentials":
            raise WrongPin(_detail(r))
        if r.status == 429:
            raise AccountLocked(_retry_after_seconds(r))
        self._raise_refusal(r)

    @staticmethod
    def _raise_refusal(r: Response, *, not_found: str = "bad_request") -> None:
        slug, detail = _slug(r), _detail(r)
        if r.status in (401, 403) and slug in ("unauthorized", "station-mismatch"):
            raise Refused("station_key_rejected", detail)
        if slug == "operator-identity-required":
            raise Refused("not_allowed", detail)
        if r.status == 404:
            raise Refused(not_found, detail)
        if slug == "pool-exhausted":
            raise Refused("master_range_used_up", detail)
        if slug == "reserve-already-held":
            b = r.body or {}
            raise Refused(
                "reserve_already_held", detail,
                open_block_id=_int_or_none(b.get("open_block_id")),
                reserve_block_id=_int_or_none(b.get("reserved_block_id")),
            )
        raise Refused("bad_request", f"{r.status} {slug}: {detail}".strip())


def _module_to_wire(m: Module) -> Dict[str, Any]:
    wire: Dict[str, Any] = {"qr": m.qr, "mac": normalize_mac(m.mac), "passed": bool(m.passed)}
    if m.note is not None:
        wire["note"] = m.note
    return wire


def _report_result(modules: List[Module], body: Dict[str, Any]) -> ReportResult:
    results = body.get("results") or []
    if len(results) != len(modules):
        raise BoxUnreachable(f"the box answered {len(results)} results for {len(modules)} modules")
    accepted: List[Module] = []
    reprogrammed: List[Module] = []
    rejected: List[Tuple[Module, str]] = []
    for m, res in zip(modules, results):
        outcome = res.get("outcome")
        if outcome == "accepted":
            accepted.append(m)
        elif outcome == "reprogrammed":
            reprogrammed.append(m)
        else:
            rejected.append((m, str(res.get("reason") or "rejected")))
    return ReportResult(
        accepted=accepted,
        reprogrammed=reprogrammed,
        rejected=rejected,
        on_hold=bool(body.get("on_hold")),
        hold_reason=body.get("hold_reason"),
    )


def _slug(r: Response) -> str:
    t = str((r.body or {}).get("type") or "")
    return t.rsplit("/", 1)[-1]


def _detail(r: Response) -> str:
    return str((r.body or {}).get("detail") or "")


def _retry_after(r: Response) -> Optional[float]:
    try:
        return float(r.headers["retry-after"])
    except (KeyError, ValueError):
        return None


def _retry_after_seconds(r: Response) -> int:
    v = _retry_after(r)
    return int(v) if v is not None else 60


def _int_or_none(v: Any) -> Optional[int]:
    return int(v) if v is not None else None
