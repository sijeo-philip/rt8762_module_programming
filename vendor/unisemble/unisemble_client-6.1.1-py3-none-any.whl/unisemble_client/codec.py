"""MAC address codec (mirrors the server codec).

Wire form is ALWAYS 12 uppercase hex characters (e.g. ``F05ECD39F108``). This is
the one canonical representation the SDK puts on the wire; the internal integer
form exists only for arithmetic (block ranges) and is never sent.

This module is deliberately tiny and device-agnostic: it converts a MAC that has
*already been obtained* (from a device, a golden rig, or an operator) to/from the
wire string. WHERE the MAC comes from is the caller's concern. Do not put device
assumptions here.
"""
from __future__ import annotations

import re

_MAC_RE = re.compile(r"^[0-9A-F]{12}$")


class InvalidMacError(ValueError):
    """A MAC value is not 12 hex digits (case-insensitive; a leading ``0x`` is allowed)."""


def is_valid_mac(mac: str) -> bool:
    """True iff ``mac`` is exactly 12 uppercase hex characters (wire form)."""
    return bool(_MAC_RE.match(mac))


def normalize_mac(mac: str) -> str:
    """Coerce a MAC to canonical wire form (12 uppercase hex) or raise.

    Accepts lower/mixed case and strips a leading ``0x``; rejects anything that
    is not 12 hex digits once normalized. The server only ever accepts the
    canonical form, so the SDK normalizes at the boundary.
    """
    if not isinstance(mac, str):
        raise InvalidMacError(f"MAC must be a string, got {type(mac).__name__}")
    candidate = mac.strip()
    if candidate.lower().startswith("0x"):
        candidate = candidate[2:]
    candidate = candidate.upper()
    if not is_valid_mac(candidate):
        raise InvalidMacError(f"MAC must be 12 uppercase hex characters: {mac!r}")
    return candidate


def mac_to_int(mac: str) -> int:
    """Wire MAC string → integer (for range arithmetic only)."""
    return int(normalize_mac(mac), 16)


def int_to_mac(value: int) -> str:
    """Integer → 12-uppercase-hex wire MAC. Rejects out-of-range values."""
    if value < 0 or value > 0xFFFFFFFFFFFF:
        raise InvalidMacError(f"MAC integer out of 48-bit range: {value}")
    return format(value, "012X")
