"""Errors raised by the SDK.

Every error derives from ``UnisembleError``, except ``InvalidMacError`` (a
``ValueError`` from ``codec``, for a MAC that is not 12 hex digits). Each class
means one thing the station application does differently.
"""
from __future__ import annotations

from typing import Optional


class UnisembleError(Exception):
    """Base class for every SDK error."""


class ClientBusy(UnisembleError):
    """Another call on this client has not finished (including its retries).
    Nothing was sent."""


class BoxUnreachable(UnisembleError):
    """No usable answer after the SDK's retries: no connection, a time-out, a
    server error, or a box that is not ready yet. ``detail`` says which."""

    def __init__(self, detail: str) -> None:
        super().__init__(detail)
        self.detail = detail


class PinChangeRequired(UnisembleError):
    """``login()``: the PIN is right, but a new one must be set first."""


class WrongPin(UnisembleError):
    """The phone number and PIN were not accepted."""


class AccountLocked(UnisembleError):
    """Too many wrong PINs for that phone. Wait ``retry_after_seconds``."""

    def __init__(self, retry_after_seconds: int) -> None:
        super().__init__(f"Too many wrong PINs. Try again in {retry_after_seconds} seconds.")
        self.retry_after_seconds = retry_after_seconds


class NotLoggedIn(UnisembleError):
    """No one is logged in on this client (``change_pin()`` or ``report()`` before
    ``login()``). Nothing was sent."""


class SessionExpired(UnisembleError):
    """``report()``: the box has ended the operator's session (idle, end of shift,
    account disabled, or logged out elsewhere). Nothing was recorded. Log in again
    and send the same modules."""


class Refused(UnisembleError):
    """Any other refusal by the box. ``reason`` says why; ``detail`` is prose for
    support. With ``reserve_already_held``, ``open_block_id`` and
    ``reserve_block_id`` name the blocks the box thinks this station holds."""

    REASONS = (
        "master_range_unknown",
        "master_range_used_up",
        "reserve_already_held",
        "block_not_found",
        "not_allowed",
        "station_key_rejected",
        "bad_request",
    )

    def __init__(
        self,
        reason: str,
        detail: str = "",
        *,
        open_block_id: Optional[int] = None,
        reserve_block_id: Optional[int] = None,
    ) -> None:
        super().__init__(f"{reason}: {detail}" if detail else reason)
        self.reason = reason
        self.detail = detail
        self.open_block_id = open_block_id
        self.reserve_block_id = reserve_block_id


class TransportError(Exception):
    """Internal: the transport got no HTTP answer at all. The client turns it into
    ``BoxUnreachable`` after its retries."""
