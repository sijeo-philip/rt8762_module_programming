"""The small data classes the station application passes in and gets back."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Tuple


@dataclass(frozen=True)
class Module:
    """One finished module, as passed to ``report()``.

    ``mac`` is the address programmed into it: 12 hex digits (lower case and a
    leading ``0x`` are accepted). ``note`` is optional free text, up to 500
    characters.
    """

    qr: str
    mac: str
    passed: bool
    note: Optional[str] = None


@dataclass(frozen=True)
class Block:
    """A block of addresses owned by this station, ``first_mac`` to ``last_mac``
    (both included, 12 upper-case hex digits)."""

    block_id: int
    first_mac: str
    last_mac: str
    size: int
    master_range: str


@dataclass(frozen=True)
class ReportResult:
    """The box's answer to ``report()``. Every module sent appears in exactly one
    list, as the same object the application passed in, in the order sent."""

    accepted: List[Module] = field(default_factory=list)
    reprogrammed: List[Module] = field(default_factory=list)
    rejected: List[Tuple[Module, str]] = field(default_factory=list)
    on_hold: bool = False
    hold_reason: Optional[str] = None


@dataclass(frozen=True)
class User:
    """The person logged in, as returned by ``login()`` (and by ``change_pin()``
    when it logs a first-time user in).

    ``user_id`` is the person's permanent id from head office: the same on every
    box, and unchanged when their phone number changes. ``role`` is ``"admin"``,
    ``"supervisor"`` or ``"user"`` on this site; a role changed at head office
    shows at the next login.
    """

    user_id: str
    name: str
    phone: str
    role: str
