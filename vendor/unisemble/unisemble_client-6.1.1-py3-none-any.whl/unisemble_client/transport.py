"""HTTP transport seam.

The client depends on the ``Transport`` Protocol, not on a concrete HTTP library.
The default ``UrllibTransport`` uses only the Python standard library (no third-
party dependency — this SDK ships dependency-free), and tests inject a
``FakeTransport`` so the whole client is exercised without a live server or a
network. This is the standard boundary seam: swap the transport, keep the client.
"""
from __future__ import annotations

import http.client
import json
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Protocol, Tuple


@dataclass(frozen=True)
class Response:
    status: int
    body: Optional[Dict[str, Any]]
    # Response headers (lower-cased keys). Defaulted empty so every existing
    # construction site + test handler stays valid; only a couple of callers read
    # it (e.g. Retry-After on a 429 account-locked).
    headers: Dict[str, str] = field(default_factory=dict)


class Transport(Protocol):
    def request(
        self,
        method: str,
        url: str,
        headers: Dict[str, str],
        body: Optional[Dict[str, Any]],
        timeout: float,
    ) -> Response:
        ...


class UrllibTransport:
    """Stdlib transport. Parses JSON bodies; never raises on HTTP status —
    it returns the (status, body) pair and lets the client map problems to
    typed errors. Raises only on a true transport failure (no response)."""

    def request(
        self,
        method: str,
        url: str,
        headers: Dict[str, str],
        body: Optional[Dict[str, Any]],
        timeout: float,
    ) -> Response:
        data = None
        if body is not None:
            data = json.dumps(body).encode("utf-8")
        req = urllib.request.Request(url=url, data=data, method=method)
        for k, v in headers.items():
            req.add_header(k, v)
        # Nested on purpose: the outer handlers also catch a failure while reading an
        # error response's body (e.read() below), which is "no answer" too.
        try:
            try:
                with urllib.request.urlopen(req, timeout=timeout) as resp:
                    raw = resp.read()
                    return Response(status=resp.status, body=_parse(raw), headers=_headers_of(resp))
            except urllib.error.HTTPError as e:  # 4xx/5xx carry a body we want
                raw = e.read()
                return Response(status=e.code, body=_parse(raw), headers=_headers_of(e))
        except urllib.error.URLError as e:  # no response — true transport failure
            from .errors import TransportError

            raise TransportError(str(e.reason)) from e
        except (OSError, http.client.HTTPException) as e:
            # No usable answer: a time-out (socket.timeout is not a TimeoutError on
            # Python 3.9), a reset, or an answer cut off or garbled mid-way
            # (IncompleteRead, BadStatusLine, RemoteDisconnected).
            from .errors import TransportError

            raise TransportError(str(e) or type(e).__name__) from e


def _headers_of(resp: Any) -> Dict[str, str]:
    """Lower-cased response headers from a urllib response/HTTPError. Both expose
    a ``.headers`` (http.client.HTTPMessage); ``.items()`` yields (key, value)."""
    hdrs = getattr(resp, "headers", None)
    if hdrs is None:
        return {}
    try:
        return {k.lower(): v for k, v in hdrs.items()}
    except Exception:
        return {}


def _parse(raw: bytes) -> Optional[Dict[str, Any]]:
    if not raw:
        return None
    try:
        return json.loads(raw.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        return None


class FakeTransport:
    """Deterministic transport for tests.

    Register handlers keyed by ``(METHOD, path)`` (path only, query stripped).
    A handler receives ``(headers, body, query)`` and returns ``(status, body)``.
    Records every call for assertions (idempotency replay, header propagation).
    """

    def __init__(self) -> None:
        # A handler returns (status, body) or (status, body, headers).
        self._handlers: Dict[Tuple[str, str], Callable[[Dict[str, str], Optional[Dict[str, Any]], Dict[str, str]], Tuple[Any, ...]]] = {}
        self.calls: List[Dict[str, Any]] = []

    def handle(self, method: str, path: str, fn) -> None:
        self._handlers[(method.upper(), path)] = fn

    def request(
        self,
        method: str,
        url: str,
        headers: Dict[str, str],
        body: Optional[Dict[str, Any]],
        timeout: float,
    ) -> Response:
        path, query = _split(url)
        self.calls.append({"method": method.upper(), "path": path, "query": query, "headers": headers, "body": body})
        key = (method.upper(), path)
        if key not in self._handlers:
            raise AssertionError(f"FakeTransport: no handler for {key}")
        result = self._handlers[key](headers, body, query)
        # A handler returns (status, body) or, when it needs to assert on response
        # headers (e.g. Retry-After on a 429), (status, body, headers).
        if len(result) == 3:
            status, resp_body, resp_headers = result
        else:
            status, resp_body = result
            resp_headers = {}
        return Response(status=status, body=resp_body, headers={k.lower(): v for k, v in (resp_headers or {}).items()})


def _split(url: str) -> Tuple[str, Dict[str, str]]:
    # url is the full URL the client built (base + path [+ ?query]).
    from urllib.parse import urlparse, parse_qsl

    parsed = urlparse(url)
    return parsed.path, dict(parse_qsl(parsed.query))
